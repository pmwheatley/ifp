#error This file is obsolete.  If you're seeing this error, simply remove dummy.c from your makefile.
