/* This is a Cfunctions (version 0.24) generated header file.
   Cfunctions is a free program for extracting headers from C files.
   Get Cfunctions from `http://www.hayamasa.demon.co.uk/cfunctions'. */

/* This file was generated with:
`cfunctions -i copying.c' */
#ifndef CFH_COPYING_H
#define CFH_COPYING_H

/* From `copying.c': */

#ifdef DEBUGGING
void show_copying (void);
void show_warranty (void);

#endif

#endif /* CFH_COPYING_H */
