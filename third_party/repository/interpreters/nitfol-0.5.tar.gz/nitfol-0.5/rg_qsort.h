/* This is a Cfunctions (version 0.24) generated header file.
   Cfunctions is a free program for extracting headers from C files.
   Get Cfunctions from `http://www.hayamasa.demon.co.uk/cfunctions'. */

/* This file was generated with:
`cfunctions -i rg_qsort.c' */
#ifndef CFH_RG_QSORT_H
#define CFH_RG_QSORT_H

/* From `rg_qsort.c': */

#endif /* CFH_RG_QSORT_H */
