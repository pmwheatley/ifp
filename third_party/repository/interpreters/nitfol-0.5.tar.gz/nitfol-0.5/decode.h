/* This is a Cfunctions (version 0.24) generated header file.
   Cfunctions is a free program for extracting headers from C files.
   Get Cfunctions from `http://www.hayamasa.demon.co.uk/cfunctions'. */

/* This file was generated with:
`cfunctions -i decode.c' */
#ifndef CFH_DECODE_H
#define CFH_DECODE_H

/* From `decode.c': */
void decode (void);

#endif /* CFH_DECODE_H */
