#include "nitfol.h"

void init_sound(void)
{
  ;
}

void kill_sound(void)
{
  ;
}

void op_sound_effect(void)
{
  ;
}

void check_sound(event_t unused)
{
  ;
}
