#ifdef DEBUGGING
void process_debug_command(const char *buffer);
BOOL exp_has_locals(const char *exp);
z_typed evaluate_expression(const char *exp, unsigned frame);
#endif
