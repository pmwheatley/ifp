//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Level9.rc
//
#define IDR_MANIFEST                    1
#define IDD_ABOUT                       100
#define IDD_ABOUTV                      105
#define IDI_ICON                        101
#define IDM_MENU                        102
#define IDC_LOGO                        103
#define IDC_GROUP                       104
#define IDA_ACCEL                       105
#define CM_OPEN                         200
#define CM_FILELOAD                     201
#define CM_FILESAVE                     202
#define CM_DICTIONARY                   203
#define CM_EXIT                         204
#define CM_FONT                         205
#define CM_HELPCONTENTS                 206
#define CM_ABOUT                        207
#define CM_PASTE                        208

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        208
#define _APS_NEXT_COMMAND_VALUE         40000
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
