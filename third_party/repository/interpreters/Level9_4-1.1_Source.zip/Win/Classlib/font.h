// font.h

void ShadowText(HDC dc,int x,int y,char *font,int size,char *string,COLORREF Col);
void CentreText(HDC dc,int x,int y,char *font,int size,char *string,COLORREF Col);
void AngleText(HDC dc,int x,int y,char *font,int size,int rot,char *string,COLORREF Col);
