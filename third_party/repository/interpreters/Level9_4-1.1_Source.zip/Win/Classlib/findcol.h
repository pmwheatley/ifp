// findcol.h

int FindCol(int Red,int Green,int Blue,RGBQUAD *Cols,int PalSize);
