LRESULT  CALLBACK NullProc( HWND hWnd, UINT iMessage, WPARAM wParam,
											LPARAM lParam );
LRESULT  CALLBACK MainWndProc( HWND hWnd, UINT iMessage, WPARAM wParam,
											LPARAM lParam );
LRESULT  CALLBACK InitialisationProc( HWND hWnd, UINT iMessage, WPARAM wParam,
											LPARAM lParam );
