This is the source code for the Windows port of Niclas Karlsson's
Magnetic interpreter. To rebuild, you will need Microsoft Visual C++
7.0 (Visual C++.NET) or newer.

