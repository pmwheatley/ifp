//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Magnetic.rc
//
#define IDR_MANIFEST                    1
#define IDR_MAINFRAME                   128
#define IDB_LOGO                        129
#define IDD_ABOUTBOX                    130
#define IDD_SCROLLBACK                  131
#define IDD_OPTIONS                     132
#define IDD_TITLE                       133
#define IDD_HINTS                       134
#define IDB_TOOLBAR32                   135
#define IDC_COPY                        1000
#define IDC_SHOWPIC                     1001
#define IDC_SCALE                       1002
#define IDC_SPIN                        1003
#define IDC_SCALET                      1004
#define IDC_TEXT                        1005
#define IDC_SPINT                       1006
#define IDC_SEED                        1007
#define IDC_FORE                        1008
#define IDC_BACK                        1009
#define IDC_GFX                         1010
#define IDC_GAMMA                       1011
#define IDC_SPING                       1012
#define IDC_SCALE_LABEL                 1013
#define IDC_TEXT_LABEL                  1014
#define IDC_BACK_LABEL                  1015
#define IDC_SCALET_LABEL                1016
#define IDC_PREDICT                     1017
#define IDC_SEED_LABEL                  1018
#define IDC_GFX_LABEL                   1019
#define IDC_GAMMA_LABEL                 1020
#define IDC_PIC_LABEL                   1021
#define IDC_ANIM_WAIT                   1022
#define IDC_HINT_WINDOW                 1023
#define IDC_SHOWHINT                    1024
#define IDC_TOPICS                      1025
#define IDC_PREVIOUS                    1026
#define IDC_HINTLIST                    1027
#define IDC_LOGO                        1028
#define IDC_CREDITS                     1029
#define ID_VIEW_FONT                    32770
#define ID_HELP_TOPICS                  32771
#define ID_FILE_RECORD                  32772
#define ID_FILE_PLAYBACK                32773
#define ID_FILE_SCRIPT                  32774
#define ID_VIEW_FLATBAR                 32775
#define ID_VIEW_SCROLLBACK              32776
#define ID_VIEW_OPTIONS                 32777
#define ID_TOGGLE_GFX                   32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           100
#endif
#endif
