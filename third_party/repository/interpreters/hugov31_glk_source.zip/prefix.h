/*
	Glk Hugo prefix file
*/

#define GLK

#include <MacTypes.h>
#include <Files.h>
#define TRUE 1
#define FALSE 0
#define NO_KEYPRESS_CURSOR
