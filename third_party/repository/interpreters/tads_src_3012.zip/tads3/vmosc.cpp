#error This file is obsolete - if you're seeing this error, simply remove vmosc.cpp from your makefile.
