"This is vers2.h - this header is for inclusion from the ansi.c test file.";
