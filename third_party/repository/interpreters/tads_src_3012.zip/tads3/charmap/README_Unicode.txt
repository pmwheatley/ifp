For information on the TADS 3 Unicode-based character set translation
system, please refer to the file "t3cmap.htm" in the "doc" subdirectory
of the TADS 3 source distribution.
