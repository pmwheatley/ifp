/*
Name
  osunix.c - extra unix support routines for TADS 3
Function
  Defines some routines for TADS 3 on Unix.  These routines are not
  required by TADS, but rather are required by the Unix osifc
  implementation.  In particular, the Unix osifc implementation makes some
  calls to TADS 2 portable functions, which are not available in TADS 3
  executables; to avoid linking errors, we provide these dummy
  implementations.

  IMPORTANT: This file should be linked only with programs that have
  BOTH the TADS 2 and TADS 3 VM's linked in; currently, the only program to
  which this applies is the combined v2+v3 interpreter.  All programs that
  link only the T3 VM should use osunix3.o instead.  (Note that everything
  links in the TADS 2 osifc implementation - that's not important.  What's
  important is whether or not the TADS 2 VM itself is linked in.  When it
  is, use osunix23.o; when it's not, use osunix3.o.)
Notes

Modified
  08/19/00 MJRoberts  - Creation
*/

#include <stdio.h>
#include <stdlib.h>


/* Dummy break handler routine */
void os_instbrk(int install){}
