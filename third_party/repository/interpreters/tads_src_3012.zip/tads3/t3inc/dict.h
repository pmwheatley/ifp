#charset "us-ascii"

/* 
 *   Copyright (c) 2000 Michael J. Roberts
 *   
 *   This file is part of TADS 3.  
 */

#ifndef _DICT_H_
#define _DICT_H_

/*
 *   'dictionary' metaclass 
 */
intrinsic class Dictionary 'dictionary/030001'
{
    findWord(str, voc_prop?);
    findWordTrunc(str, voc_prop?);
    setTruncLen(len);
    addWord(obj, str, voc_prop);
    removeWord(obj, str, voc_prop);
    isWordDefined(str);
    isWordDefinedTrunc(str);
}

#endif /* _DICT_H_ */
