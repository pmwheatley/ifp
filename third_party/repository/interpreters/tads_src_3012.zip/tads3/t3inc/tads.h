#charset "us-ascii"

/* 
 *   Copyright (c) 1999, 2000 by Michael J. Roberts
 *   
 *   This file is part of TADS 3 
 */

/*
 *   TADS basic data manipulation intrinsic function set 
 */

#ifndef TADS_H
#define TADS_H

/* include the T3 VM intrinsic function set */
#include "t3.h"

/* include the TADS general data manipulation function set */
#include "tadsgen.h"

/* include the TADS input/output function set */
#include "tadsio.h"

/* include the system type definitions */
#include "systype.h"
 
#endif /* _TADS_H */

