#ifdef GLK_ANSI_ONLY
#include "tads2/askf_tx.c"
#else
#include "tads2/askf_os.c"
#endif
