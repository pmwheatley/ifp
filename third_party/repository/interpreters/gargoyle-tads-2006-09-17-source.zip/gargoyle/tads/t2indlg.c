#include "tads2/indlg_tx.c"

