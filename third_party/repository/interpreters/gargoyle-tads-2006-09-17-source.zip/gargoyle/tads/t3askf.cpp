#ifdef GLK_ANSI_ONLY
#include "tads3/askf_tx.cpp"
#else
#include "tads3/askf_os.cpp"
#endif
